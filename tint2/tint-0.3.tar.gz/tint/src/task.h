
#ifndef TASK_H
#define TASK_H

#include <X11/Xlib.h>

typedef struct Task
{
   struct Task *next;
   Window win;
   long *icon_data;
   int icon_width;
   int icon_height;
   Pixmap pmap;
   Pixmap active_pmap;
   // need to redraw Pixmap
   int redraw_pixmap;
   char *title;
   unsigned int active;
   int desktop;
   int pos_x;
   int width;
} Task;

typedef struct task_global
{
   Task *tasklist;
   int task_count;
} task_global;

task_global task;

Task *task_get_task (Window win);
void set_redraw_all ();
void task_refresh_tasklist ();
void task_remove_task (Window win);
void resize_tasks ();
void refresh_pos_x ();

#endif
