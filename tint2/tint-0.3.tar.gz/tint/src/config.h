#include <pango/pangocairo.h>

typedef struct config_border
{
   double color[3];
   double alpha;
   int width;
   int rounded;
} config_border;

typedef struct config_back
{
   double color[3];
   double alpha;
} config_back, config_font;

// mouse actions
enum { NONE=0, CLOSE, TOGGLE, ICONIFY, SHADE, TOGGLE_ICONIFY };

//panel alignment
enum { LEFT, RIGHT, CENTER };

typedef struct config_global
{
   PangoFontDescription *font_desc;
   config_font font;
   config_font font_active;
   int font_shadow;

   int number_of_desktops;
   
   // panel parameters
   int panel_show_all_taskbar;
   int panel_width;
   int panel_height;
   int panel_margin;
   int panel_position;
   int panel_taskbar_width;

   int panel_background;
   config_back panel_back;
   config_border panel_border;

   // tasks parameters
   int task_text_centered;
   int task_height;
   int task_maximum_width;
   int task_margin;
   int task_padding;
   int task_icon;
   int task_icon_size;

   int task_background;
   int task_background_as_border;
   config_back task_back;
   config_back task_active_back;
   config_border task_border;
   config_border task_active_border;

   // mouse events
   int mouse_middle;
   int mouse_right;
   int mouse_scroll_up;
   int mouse_scroll_down;
   
   // launcher parameters
   int launcher_width;

   // starting position for text ~ task_padding + icon_size
   double task_text_posx, task_text_posy;
   int task_text_width;
   
   // icon position
   int task_icon_posy;
} config_global;

config_global config;

void config_read ();
void config_finish ();
void config_free ();
void printtime();

