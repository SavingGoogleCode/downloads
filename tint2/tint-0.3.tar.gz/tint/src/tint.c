/**************************************************************************
*
* Tint Task Manager
* 
* Copyright (C) 2007 Pål Staurland (staura@gmail.com)
* Modified (C) 2008 thierry lorthiois (lorthiois@bbsoft.fr)
* 
* Permission is hereby granted, free of charge, to any person obtaining a
* copy of this software and associated documentation files (the "Soft-
* ware"), to deal in the Software without restriction, including without
* limitation the rights to use, copy, modify, merge, publish, distribute,
* sublicense, and/or sell copies of the Software, and to permit persons to
* whom the Software is furnished to do so, subject to the following condi-
* tions:
* 
* The above copyright notice and this permission notice shall be included
* in all copies or substantial portions of the Software.
* 
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
* OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABIL-
* ITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT
* SHALL THE AUTHOR BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT
* OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
* THE SOFTWARE.
* 
**************************************************************************/

#include <unistd.h>
#include <X11/Xutil.h>
#include <X11/Xatom.h>
#include <X11/Xlocale.h>
#include <Imlib2.h> 
#include <stdio.h>
#include <stdlib.h>
#include "server.h"
#include "visual.h"
#include "config.h"
#include "task.h"
#include "window.h"


/* just for test purpose
#include <signal.h>
void sigquit()
{
   Task *tsk;

   tsk = task.tasklist;
   while (tsk) {
      task_remove_task (tsk->win);
      tsk = tsk->next;
   }
   config_free ();
   exit(0);
}
*/


void init ()
{
   //signal(SIGINT, sigquit);

   server.dsp = XOpenDisplay (NULL);
   if (!server.dsp) {
      fprintf(stderr, "Could not open display.\n");
      exit(0);
   }
   server_init_atoms ();
   server.screen = DefaultScreen (server.dsp);
   server.root_win = RootWindow (server.dsp, server.screen);
   server.depth = DefaultDepth (server.dsp, server.screen);
   server.visual = DefaultVisual (server.dsp, server.screen);
   server.screen_height = DisplayHeight (server.dsp, server.screen);
   server.screen_width = DisplayWidth (server.dsp, server.screen);
   server.desktop = server_get_current_desktop ();
   server.gc = DefaultGC (server.dsp, 0);
   XSetErrorHandler ((XErrorHandler) server_catch_error);
   server.got_root_pmap = 0;
   server.got_root_win = 0;
   server.pmap = 0;
   server.root_pmap = 0;

   imlib_context_set_display (server.dsp);
   imlib_context_set_visual (server.visual);
   imlib_context_set_colormap (DefaultColormap (server.dsp, server.screen));

   /* Catch events */
   XSelectInput (server.dsp, server.root_win, PropertyChangeMask|StructureNotifyMask);

   task.tasklist = 0;
   task.task_count = 0;
}


void event_button_press (int button, int x, int y)
{
   Task *tsk;
   tsk = task.tasklist;
   while (tsk) {
      if ((tsk->desktop == 0xFFFFFFFF) || (server.desktop == tsk->desktop)) {
         if (x >= tsk->pos_x && x <= tsk->pos_x + tsk->width) {
            switch (button) {
               case 1:
                  window_action (tsk, TOGGLE_ICONIFY);
                  break;
               case 4:
                  window_action (tsk, config.mouse_scroll_up);
                  break;
               case 5:
                  window_action (tsk, config.mouse_scroll_down);
                  break;
               case 2:
                  window_action (tsk, config.mouse_middle);
                  break;
               case 3:
                  window_action (tsk, config.mouse_right);
                  break;
            }
         }
      }
      tsk = tsk->next;
   }

   /* Fix to keep window below */
   XLowerWindow (server.dsp, window.main_win);
}


void event_property_notify (Window win, Atom at)
{
   //printf("atom= %s", XGetAtomName(server.dsp, at));

   if (win == server.root_win) {
      //printf(" traitement");
      if (!server.got_root_win) {
         XSelectInput (server.dsp, server.root_win, PropertyChangeMask|StructureNotifyMask);
         server.got_root_win = 1;
      }

      /* New desktop */
      if (at == server.atom._NET_CURRENT_DESKTOP) {
         server.desktop = server_get_current_desktop ();
         resize_tasks ();
         refresh_visual ();
      }
      /* Window list */
      else if (at == server.atom._NET_CLIENT_LIST) {
         task_refresh_tasklist ();
         refresh_visual ();
      }
      /* Active */
      else if (at == server.atom._NET_ACTIVE_WINDOW) {
         Window win;
         Task *tsk;

         win = window_get_active ();
         tsk = task.tasklist;
         while (tsk) {
            tsk->active = 0;
            if (tsk->win == win) tsk->active = 1;
            tsk = tsk->next;
         }
         refresh_visual ();
      }
      /* Wallpaper changed */
      else if (at == server.atom._XROOTPMAP_ID) {
         XFreePixmap (server.dsp, server.pmap);
         server.got_root_pmap = 0;
         set_redraw_all ();
         refresh_visual ();
      }
   }
   else {
      Task *tsk;
      tsk = task_get_task (win);
      if (!tsk) return;

      /* Window title changed */
      if (at == server.atom._NET_WM_VISIBLE_NAME) {
         if (tsk->title) XFree (tsk->title);
         tsk->title = server_get_property (win, server.atom._NET_WM_VISIBLE_NAME, server.atom.UTF8_STRING, 0);
         tsk->redraw_pixmap = 1;
         refresh_visual ();
      }
      /* Window icon changed */
      else if (at == server.atom._NET_WM_ICON) {
         if (tsk->icon_data != 0) XFree (tsk->icon_data);
         tsk->redraw_pixmap = 1;
         tsk->icon_data = 0;
         refresh_visual ();
      }
      /* Window desktop changed */
      else if (at == server.atom._NET_WM_DESKTOP) {
         tsk->desktop = window_get_desktop (win);
         resize_tasks ();
         refresh_visual ();
      }

      if (!server.got_root_win) server.root_win = RootWindow (server.dsp, server.screen);
   }
   //printf("\n");
}


int main (int argc, char *argv[])
{
   XEvent e;
   fd_set fd;
   int xfd;

   init ();
   config_read ();
   config_finish ();

   window_draw_panel ();

   task_refresh_tasklist ();
   resize_tasks ();

   server_refresh_root_pixmap ();
   server_refresh_main_pixmap ();
   visual_draw_launcher ();
   visual_draw_tasks ();
   server_refresh_main_pixmap ();

   xfd = ConnectionNumber (server.dsp);
   XSync (server.dsp, False);

        
   while (1) {
      FD_ZERO (&fd);
      FD_SET (xfd, &fd);
      select (xfd + 1, &fd, 0, 0, 0);

      while (XPending (server.dsp)) {
         XNextEvent(server.dsp, &e);
         switch (e.type) {
            case ButtonPress:
            event_button_press (e.xbutton.button, e.xbutton.x, e.xbutton.y);
            break;

            case DestroyNotify:
            task_remove_task (e.xdestroywindow.window);
            refresh_visual ();
            break;

            case Expose:
            server_refresh_main_pixmap ();
            break;

            case PropertyNotify:
            event_property_notify (e.xproperty.window, e.xproperty.atom);
            break;

            default:
            break;
         }
      }
   }
   return 0;
}

