
void visual_draw_tasks ();
void visual_draw_launcher ();

