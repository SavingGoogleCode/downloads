/**************************************************************************
*
* Tint Task Manager
* 
* Copyright (C) 2007 Pål Staurland (staura@gmail.com)
* 
* Permission is hereby granted, free of charge, to any person obtaining a
* copy of this software and associated documentation files (the "Soft-
* ware"), to deal in the Software without restriction, including without
* limitation the rights to use, copy, modify, merge, publish, distribute,
* sublicense, and/or sell copies of the Software, and to permit persons to
* whom the Software is furnished to do so, subject to the following condi-
* tions:
* 
* The above copyright notice and this permission notice shall be included
* in all copies or substantial portions of the Software.
* 
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
* OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABIL-
* ITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT
* SHALL THE AUTHOR BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT
* OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
* THE SOFTWARE.
* 
**************************************************************************/

#include <X11/Xutil.h>
#include <X11/Xatom.h>
#include <X11/Xlocale.h>
#include <Imlib2.h> 
#include <stdio.h>
#include <stdlib.h>
#include "server.h"
#include "visual.h"
#include "config.h"
#include "task.h"
#include "window.h"
#include "event.h"

void init ()
{
   server.dsp = XOpenDisplay (NULL);
   if (!server.dsp) {
      fprintf(stderr, "Could not open display.\n");
      exit(0);
   }
   server_init_atoms ();
   server.screen = DefaultScreen (server.dsp);
   server.root_win = RootWindow (server.dsp, server.screen);
   server.depth = DefaultDepth (server.dsp, server.screen);
   server.visual = DefaultVisual (server.dsp, server.screen);
   server.screen_height = DisplayHeight (server.dsp, server.screen);
   server.screen_width = DisplayWidth (server.dsp, server.screen);
   server.desktop = server_get_current_desktop ();
   server.gc = DefaultGC (server.dsp, 0);
   XSetErrorHandler ((XErrorHandler) server_catch_error);
   server.got_root_pmap = 0;
   server.got_root_win = 0;
   server.pmap = 0;
   server.root_pmap = 0;

   imlib_context_set_display (server.dsp);
   imlib_context_set_visual (server.visual);
   imlib_context_set_colormap (DefaultColormap (server.dsp, server.screen));

   /* Catch events */
   XSelectInput (server.dsp, server.root_win, PropertyChangeMask|StructureNotifyMask);

   task.tasklist = 0;
   task.task_count = 0;
}

int main (int argc, char *argv[])
{
   XEvent e;
   fd_set fd;
   int xfd;

   init ();
   config_read ();
   config_finish ();

   window_draw_panel ();

   task_refresh_tasklist ();
   resize_tasks ();

   server_refresh_root_pixmap ();
   server_refresh_main_pixmap ();
   visual_draw_launcher ();
   visual_draw_tasks ();
   server_refresh_main_pixmap ();

   xfd = ConnectionNumber (server.dsp);
   XSync (server.dsp, False);

        
   while (1) {
      FD_ZERO (&fd);
      FD_SET (xfd, &fd);
      select (xfd + 1, &fd, 0, 0, 0);

      while (XPending (server.dsp)) {
         XNextEvent(server.dsp, &e);
         switch (e.type) {
            case ButtonPress:
            event_button_press (e.xbutton.button, e.xbutton.x, e.xbutton.y);
            break;

            case DestroyNotify:
            event_destroy_notify (e.xdestroywindow.window);
            break;

            case Expose:
            event_expose();
            break;

            case PropertyNotify:
            event_property_notify (e.xproperty.window, e.xproperty.atom);
            break;

            default:
            break;
         }
      }
   }
   config_free ();
   return 0;
}

