typedef struct window_global
{
        Window main_win;
}
window_global;
window_global window;

int window_is_hidden (Window win);
void window_make_active (Window win);
int window_is_active (Window win);
int window_is_iconified (Window win);
void window_toggle_shade (Window win);
void window_draw_panel ();
int window_get_desktop (Window win);
Window window_get_active ();
void window_get_icon (Task *tsk);

