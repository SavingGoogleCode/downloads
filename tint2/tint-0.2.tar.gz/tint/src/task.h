
typedef struct Task
{
        struct Task *next;
        Window win;
        long *icon_data;
        int icon_width;
        int icon_height;
        unsigned int need_refresh;
        char *title;
        unsigned int iconified;
        unsigned int active;
        Pixmap pmap;
        Pixmap active_pmap;
        int desktop;
        int pos_x;
        int width;
} Task;

typedef struct task_global
{
        Task *tasklist;
        int task_count;
} task_global;

task_global task;

Task *task_get_task (Window win);
void task_refresh_tasklist ();
void task_remove_task (Window win);
void task_new_desktop ();
void resize_tasks ();
void refresh_pos_x ();

