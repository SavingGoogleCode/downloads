
void event_destroy_notify (Window win);
void event_button_press (int button, int x, int y);
void event_expose ();
void event_property_notify (Window win, Atom at);
