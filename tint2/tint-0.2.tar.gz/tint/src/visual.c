/**************************************************************************
*
* Tint Task Manager
*
* Copyright (C) 2007 Pål Staurland (staura@gmail.com)
* Modified (C) 05-2008 thil7 (lorthiois@bbsoft.fr)
*
* Permission is hereby granted, free of charge, to any person obtaining a
* copy of this software and associated documentation files (the "Soft-
* ware"), to deal in the Software without restriction, including without
* limitation the rights to use, copy, modify, merge, publish, distribute,
* sublicense, and/or sell copies of the Software, and to permit persons to
* whom the Software is furnished to do so, subject to the following condi-
* tions:
*
* The above copyright notice and this permission notice shall be included
* in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
* OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABIL-
* ITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT
* SHALL THE AUTHOR BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT
* OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
* THE SOFTWARE.
*
**************************************************************************/

#include <cairo.h>
#include <cairo-xlib.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pango/pangocairo.h>
#include <X11/extensions/shape.h>
#include <X11/Xatom.h>
#include <Imlib2.h>
#include "visual.h"
#include "server.h"
#include "config.h"
#include "task.h"
#include "launcher.h"
#include "window.h"

char *get_title (Task *tsk)
{
       if (!tsk->title || !strlen (tsk->title))
               return "Untitled";
       else
               return tsk->title;
}


void draw_task_icon (Task *tsk, Pixmap *pmap, int text_width)
{
   if (tsk->icon_data == 0) return;

   /* Find pos */
   int pos_x, txt_start_pnt;
   if (config.task_text_centered) {
      txt_start_pnt = (tsk->width - text_width) / 2;
      pos_x = txt_start_pnt - (config.task_icon_size - 5);
   }
   else pos_x = config.task_padding;
       

   //printf("render and draw icon\n");
   /* Render */
   Imlib_Image icon;
   Imlib_Color_Modifier cmod;
   DATA8 red[256], green[256], blue[256], alpha[256];

   icon = imlib_create_image_using_data (tsk->icon_width, tsk->icon_height, (DATA32 *)tsk->icon_data);
   imlib_context_set_image (icon);
   imlib_context_set_drawable (*pmap);

   cmod = imlib_create_color_modifier ();
   imlib_context_set_color_modifier (cmod);
   imlib_image_set_has_alpha (1);
   imlib_get_color_modifier_tables (red, green, blue, alpha);

   int i;
   if (!tsk->active) {
      /* Have no idea what I'm doing here, but it works */
      for(i = 127; i < 256; i++) alpha[i] = 100;
   }
       
   imlib_set_color_modifier_tables (red, green, blue, alpha);
   
   //imlib_render_image_on_drawable (pos_x, pos_y);
   imlib_render_image_on_drawable_at_size (pos_x, config.task_icon_posy, config.task_icon_size, config.task_icon_size);
   
   imlib_free_color_modifier ();
   imlib_free_image ();
}


void draw_task_title (cairo_t *c, Task *tsk)
{
   PangoLayout *layout;
   config_font *config_text;
   int height, width;

   /* Layout */
   layout = pango_cairo_create_layout (c);
   pango_layout_set_font_description (layout, config.font_desc);
   pango_layout_set_text (layout, get_title (tsk), -1);

   /* Drawing width and Cut text */
   pango_layout_set_width (layout, config.task_text_width * PANGO_SCALE);
   pango_layout_set_ellipsize (layout, PANGO_ELLIPSIZE_END);

   /* Center text */
   if (config.task_text_centered) pango_layout_set_alignment (layout, PANGO_ALIGN_CENTER);
   else pango_layout_set_alignment (layout, PANGO_ALIGN_LEFT);

   pango_layout_get_pixel_size (layout, &width, &height);

   if (tsk->active) config_text = &config.font_active;
   else config_text = &config.font;

   cairo_set_source_rgba (c, config_text->color[0], config_text->color[1], config_text->color[2], config_text->alpha);

   pango_cairo_update_layout (c, layout);
   cairo_move_to (c, config.task_text_posx, config.task_text_posy);
   pango_cairo_show_layout (c, layout);

   if (config.font_shadow) {
      cairo_set_source_rgba (c, 0.0, 0.0, 0.0, 0.5);
      pango_cairo_update_layout (c, layout);
      cairo_move_to (c, config.task_text_posx + 1, config.task_text_posy + 1);
      pango_cairo_show_layout (c, layout);
   }
   
   g_object_unref (layout);

   if (config.task_icon) {
      if (tsk->active) draw_task_icon (tsk, &tsk->active_pmap, width);
      else draw_task_icon (tsk, &tsk->pmap, width);
   }
}


void draw_roundedrec(cairo_t *c, int x, int y, int w, int h, int r)
{
   cairo_move_to(c, x+r, y);
   cairo_line_to(c, x+w-r, y);
   cairo_curve_to(c, x+w,y, x+w, y, x+w, y+r);
   cairo_line_to(c, x+w, y+h-r);
   cairo_curve_to(c, x+w, y+h, x+w, y+h, x+w-r, y+h);
   cairo_line_to(c, x+r, y+h);
   cairo_curve_to(c, x, y+h, x, y+h, x, y+h-r);
   cairo_line_to(c, x, y+r);
   cairo_curve_to(c, x, y, x, y, x+r, y);
}


void draw_task_background (cairo_t *c, Task *tsk)
{
   config_border *border;
   config_back  *back;
   
   if (tsk->active) {
      border = &config.task_active_border;
      back = &config.task_active_back;
   }
   else {
      border = &config.task_border;
      back = &config.task_back;
   }
   
   if (border->width) cairo_set_line_width (c, border->width);
   
   if (config.task_background_as_border) {
      if (border->rounded)
         draw_roundedrec (c, 0, config.task_height - 3, tsk->width, 3, border->rounded);
      else
         cairo_rectangle(c, 0, config.task_height - 3, tsk->width, 3);
   }
   else {
      if (border->rounded)
         draw_roundedrec (c, 0, 0, tsk->width, config.task_height, border->rounded);
      else
         cairo_rectangle(c, 0, 0, tsk->width, config.task_height);
   }
   
   if (border->width) {
      cairo_set_source_rgba (c, border->color[0], border->color[1], border->color[2], border->alpha);
      cairo_stroke_preserve (c);
   }
   
   cairo_set_source_rgba (c, back->color[0], back->color[1], back->color[2], back->alpha);
   cairo_fill (c);
}


void draw_panel_background ()
{
   cairo_surface_t *cs;
   cairo_t *c;
   double alpha;

   //cairo_set_line_width (c, 0);
   cs = cairo_xlib_surface_create (server.dsp, server.pmap, server.visual, config.panel_width, config.panel_height);
   c = cairo_create (cs);

   if (!server.got_root_pmap) {
      // No wallpaper, no alpha
      alpha = 1.0;
   }
   else alpha = config.panel_back.alpha;
   
   if (config.panel_border.width) cairo_set_line_width (c, config.panel_border.width);
   
   if (config.panel_border.rounded)
      draw_roundedrec (c, 0, 0, config.panel_width, config.panel_height, config.panel_border.rounded);
   else
      cairo_rectangle(c, 0, 0, config.panel_width, config.panel_height);
   
   if (config.panel_border.width) {
      cairo_set_source_rgba (c, config.panel_border.color[0], config.panel_border.color[1], config.panel_border.color[2], config.panel_border.alpha);
      cairo_stroke_preserve (c);
   }
   
   cairo_set_source_rgba (c, config.panel_back.color[0], config.panel_back.color[1], config.panel_back.color[2], alpha);
   cairo_fill (c);
   
   cairo_destroy (c);
   cairo_surface_destroy (cs);
}


void refresh_task (Task *tsk)
{
   cairo_surface_t *cs;
   cairo_t *c;
   unsigned int tmp_active;

   if (tsk->icon_data == 0) window_get_icon (tsk);

   /* Save original active state and restore later */
   tmp_active = tsk->active;

   // draw inactive pixmap
   tsk->active = 0;
   if (tsk->pmap != 0) XFreePixmap (server.dsp, tsk->pmap);

   tsk->pmap = server_create_pixmap (tsk->width, config.task_height);
   cs = cairo_xlib_surface_create (server.dsp, tsk->pmap, server.visual, tsk->width, config.task_height);
   c = cairo_create (cs);

   /* Copy over root pixmap */
   XCopyArea (server.dsp, server.pmap, tsk->pmap, server.gc, tsk->pos_x, config.panel_margin, tsk->width, config.task_height, 0, 0);

   /* Refresh task visuals */
   if (config.task_background) draw_task_background (c, tsk);
   draw_task_title (c, tsk);

   cairo_destroy (c);
   cairo_surface_destroy (cs);

   // draw active pixmap
   tsk->active = 1;
   if (tsk->active_pmap != 0) XFreePixmap (server.dsp, tsk->active_pmap);

   tsk->active_pmap = server_create_pixmap (tsk->width, config.task_height);
   cs = cairo_xlib_surface_create (server.dsp, tsk->active_pmap, server.visual, tsk->width, config.task_height);
   c = cairo_create (cs);

   /* Copy over root pixmap */
   XCopyArea (server.dsp, server.pmap, tsk->active_pmap, server.gc, tsk->pos_x, config.panel_margin, tsk->width, config.task_height, 0, 0);

   /* Refresh task visuals */
   if (config.task_background) draw_task_background (c, tsk);
   draw_task_title (c, tsk);

   cairo_destroy (c);
   cairo_surface_destroy (cs);

   tsk->need_refresh = 0;
   tsk->active = tmp_active;
}


void visual_draw_tasks ()
{
   Task *tsk;
   Pixmap *pmap;

   if (config.panel_background) draw_panel_background ();

   tsk = task.tasklist;
   while (tsk) {
      if (tsk->need_refresh) refresh_task (tsk);

      if (tsk->active) pmap = &tsk->active_pmap;
      else pmap = &tsk->pmap;

      XCopyArea (server.dsp, *pmap, server.pmap, server.gc, 0, 0, tsk->width, config.task_height, tsk->pos_x, config.panel_margin);

      tsk = tsk->next;
   }
}

void visual_draw_launcher ()
{
   //Launcher *lch;
   
}

