#ifndef CONFIG_H
#define CONFIG_H

#include <pango/pangocairo.h>
#include "task.h"


typedef struct config_border
{
   double color[3];
   double alpha;
   int width;
   int rounded;
} config_border;


typedef struct config_back
{
   double color[3];
   double alpha;
} config_back, config_font;


// mouse actions
enum { NONE=0, CLOSE, TOGGLE, ICONIFY, SHADE, TOGGLE_ICONIFY };

//panel alignment
enum { LEFT=0x01, RIGHT=0x02, CENTER=0X04, TOP=0X08, BOTTOM=0x10 };


typedef struct Panel {
   int show_all_desktop;
   int nbDesktop;
   int position;
   int margin;
   int posx;
   int width;
   int height;

   // panel background
   int drawBackground;
   config_back background;
   config_border border;

   // panel font
   PangoFontDescription *font_desc;
   config_font font;
   config_font font_active;
   int font_shadow;

   // taskbar parameters
   Taskbar *taskbar;
   Task   *task_active;
   Task   *task_drag;   
   
   // tasks parameters
   int task_height;
   int task_text_centered;
   int task_maximum_width;
   int task_margin;
   int task_padding;
   int task_icon;
   int task_icon_size;
   // icon position
   int task_icon_posy;
   // starting position for text ~ task_padding + icon_size
   double task_text_posx, task_text_posy;

   int task_background;
   int task_background_as_border;
   config_back task_back;
   config_back task_active_back;
   config_border task_border;
   config_border task_active_border;

   // launcher parameters
   int launcher_width;

   // mouse events
   int mouse_middle;
   int mouse_right;
   int mouse_scroll_up;
   int mouse_scroll_down;
} Panel;

Panel panel;


void config_read ();
void alloc_taskbar(int copyOldTaskbar);
void config_finish ();
void config_free ();

#endif
