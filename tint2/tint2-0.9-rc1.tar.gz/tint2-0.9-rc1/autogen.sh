#!/bin/sh

[ ! -d m4 ] && mkdir m4

autoreconf -i -s -f -v
