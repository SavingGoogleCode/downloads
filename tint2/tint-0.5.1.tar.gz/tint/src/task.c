/**************************************************************************
*
* Tint Task Manager
* 
* Copyright (C) 2007 Pål Staurland (staura@gmail.com)
* Modified (C) 2008 thierry lorthiois (lorthiois@bbsoft.fr)
* 
* Permission is hereby granted, free of charge, to any person obtaining a
* copy of this software and associated documentation files (the "Soft-
* ware"), to deal in the Software without restriction, including without
* limitation the rights to use, copy, modify, merge, publish, distribute,
* sublicense, and/or sell copies of the Software, and to permit persons to
* whom the Software is furnished to do so, subject to the following condi-
* tions:
* 
* The above copyright notice and this permission notice shall be included
* in all copies or substantial portions of the Software.
* 
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
* OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABIL-
* ITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT
* SHALL THE AUTHOR BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT
* OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
* THE SOFTWARE.
* 
**************************************************************************/

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xatom.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <glib.h>
#include "task.h"
#include "server.h"
#include "window.h"
#include "config.h"


void add_task (Window win)
{
   Task *new_tsk, *t;
   int desktop;

   if (!win || window_is_hidden (win) || win == window.main_win) return;

   new_tsk = calloc(1, sizeof(Task));
   new_tsk->win = win;
   window_get_icon (new_tsk);
   window_get_title(new_tsk);
   desktop = window_get_desktop (new_tsk->win);
   new_tsk->desktop = desktop;
   new_tsk->redraw = 1;
   XSelectInput (server.dsp, new_tsk->win, PropertyChangeMask|StructureNotifyMask);
   
   if (desktop == 0xFFFFFFFF) {
      XFree (new_tsk->title);
      free(new_tsk);
      fprintf(stderr, "task on all desktop : ignored\n");
      return;
   }
   
   /* Append */
   panel.taskbar[desktop].nbTask++;
   for (t = panel.taskbar[desktop].tasklist; t ; t = t->next)
      if (!t->next) break;
   
   if (!t) panel.taskbar[desktop].tasklist = new_tsk;
   else t->next = new_tsk;

   if (refresh_pos (desktop)) set_redraw_desktop (desktop);
   //printf("add task %s, desktop %d, nbTask %d\n", new_tsk->title, desktop, panel.taskbar[desktop].nbTask);
}


void remove_task (Task *tsk)
{
   Task *t, *p;

   if (!tsk) return;
   
   for (p = 0, t = panel.taskbar[tsk->desktop].tasklist; t ; p = t, t = t->next)
      if (t == tsk) break;
   if (!t) return;
   
   panel.taskbar[tsk->desktop].nbTask--;

   if (!p) panel.taskbar[tsk->desktop].tasklist = t->next;
   else p->next = t->next;

   if (refresh_pos (tsk->desktop)) set_redraw_desktop (tsk->desktop);
   else {
      // redraw following task
      for (p = t->next; p ; p = p->next) p->redraw = 1;
   }

   XFree (t->title);
   if (t->icon_data != 0) XFree (t->icon_data);
   XFreePixmap (server.dsp, t->pmap);
   XFreePixmap (server.dsp, t->active_pmap);
   free(t);
   //printf("delete task %s, desktop %d nbTask %d\n", tsk->title, tsk->desktop, panel.taskbar[tsk->desktop].nbTask);
}


Task *task_get_task (Window win)
{
   Task *tsk;
   int i;
   
   for (i=0 ; i < panel.nbDesktop ; i++) {
      for (tsk = panel.taskbar[i].tasklist; tsk ; tsk = tsk->next) {
         if (win == tsk->win) return tsk;
      }
   }
   //printf("task_get_task return 0\n");
   return 0;
}


void set_redraw_all ()
{
   int i;
   
   for (i=0 ; i < panel.nbDesktop ; i++) set_redraw_desktop (i);
}


void set_redraw_desktop (int desktop)
{
   Task *tsk;
   
   for (tsk = panel.taskbar[desktop].tasklist; tsk ; tsk = tsk->next) tsk->redraw = 1;
}


void task_refresh_tasklist ()
{
   Task *tsk, *next;
   Window *win, active_win;
   int num_results, i, j;

   win = server_get_property (server.root_win, server.atom._NET_CLIENT_LIST, XA_WINDOW, &num_results);

   if (!win) return;
   //printf("task_refresh_tasklist\n");
   
   /* Remove any old and set active win */
   active_win = window_get_active ();
   
   for (i=0 ; i < panel.nbDesktop ; i++) {
      tsk = panel.taskbar[i].tasklist;
      while (tsk) {
         if (tsk->win == active_win) panel.task_active = tsk;
         
         next = tsk->next;
         for (j = 0; j < num_results; j++) {
            if (tsk->win == win[j]) break;
         }
         if (tsk->win != win[j]) remove_task (tsk);

         tsk = next;
      }
   }
   
   /* Add any new */
   for (i = 0; i < num_results; i++) {
      if (!task_get_task (win[i])) add_task (win[i]);
   }

   XFree (win);
}


int refresh_pos (int desktop)
{
   int ret, task_count, pixel_width, modulo_width=0;
   int x, delta, taskbar_width;
   Task *t;

   // new task width for 'desktop'
   task_count = panel.taskbar[desktop].nbTask;
   if (!task_count) pixel_width = panel.task_maximum_width;
   else {
      taskbar_width = panel.taskbar[desktop].width - ((task_count-1) * panel.task_margin);

      pixel_width = taskbar_width / task_count;
      if (pixel_width > panel.task_maximum_width) pixel_width = panel.task_maximum_width;
      else modulo_width = taskbar_width % task_count;
   }

   if ((panel.taskbar[desktop].task_width == pixel_width) && (panel.taskbar[desktop].task_modulo == modulo_width)) {
      ret = 0;
   }
   else {
      ret = 1;      
      panel.taskbar[desktop].task_width = pixel_width;
      panel.taskbar[desktop].task_modulo = modulo_width;
      panel.taskbar[desktop].text_width = pixel_width - panel.task_text_posx - panel.task_padding;
   }
      
   // change pos_x and width for all tasks on the desktop
   delta = 0;
   x = panel.taskbar[desktop].posx;
   for (t = panel.taskbar[desktop].tasklist; t ; t = t->next) {
      t->posx = x;
      t->width = pixel_width;
      delta += modulo_width;
      if (delta > 10) {
         delta -= 10;
         t->width++;
      }

      x += t->width + panel.task_margin;
   }
   return ret;
}


