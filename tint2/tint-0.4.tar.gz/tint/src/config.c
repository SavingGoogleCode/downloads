/**************************************************************************
*
* Tint Task Manager
*
* Copyright (C) 2007 Pål Staurland (staura@gmail.com)
* Modified (C) 2008 thierry lorthiois (lorthiois@bbsoft.fr)
*
* Permission is hereby granted, free of charge, to any person obtaining a
* copy of this software and associated documentation files (the "Soft-
* ware"), to deal in the Software without restriction, including without
* limitation the rights to use, copy, modify, merge, publish, distribute,
* sublicense, and/or sell copies of the Software, and to permit persons to
* whom the Software is furnished to do so, subject to the following condi-
* tions:
*
* The above copyright notice and this permission notice shall be included
* in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
* OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABIL-
* ITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT
* SHALL THE AUTHOR BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT
* OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
* THE SOFTWARE.
*
**************************************************************************/

#include <cairo.h>
#include <cairo-xlib.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xatom.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <glib.h>
#include <pango/pangocairo.h>
#include <Imlib2.h>
#include "config.h"
#include "launcher.h"
#include "task.h"
#include "server.h"


int hex_char_to_int (char c)
{
   int r;
   
   if (c >= '0' && c <= '9')  r = c - '0';
   else if (c >= 'a' && c <= 'f')  r = c - 'a' + 10;
   else if (c >= 'A' && c <= 'F')  r = c - 'A' + 10;
   else  r = 0;

   return r;
}


int hex_to_rgb (char *hex, int *r, int *g, int *b)
{
   int len;

   if (hex == NULL || hex[0] != '#') return (0);

   len = strlen (hex);
   if (len == 3 + 1) {
      *r = hex_char_to_int (hex[1]);
      *g = hex_char_to_int (hex[2]);
      *b = hex_char_to_int (hex[3]);
   }
   else if (len == 6 + 1) {
      *r = hex_char_to_int (hex[1]) * 16 + hex_char_to_int (hex[2]);
      *g = hex_char_to_int (hex[3]) * 16 + hex_char_to_int (hex[4]);
      *b = hex_char_to_int (hex[5]) * 16 + hex_char_to_int (hex[6]);
   }
   else if (len == 12 + 1) {
      *r = hex_char_to_int (hex[1]) * 16 + hex_char_to_int (hex[2]);
      *g = hex_char_to_int (hex[5]) * 16 + hex_char_to_int (hex[6]);
      *b = hex_char_to_int (hex[9]) * 16 + hex_char_to_int (hex[10]);
   }
   else return 0;

   return 1;
}


void get_color (char *hex, double *rgb)
{
   int r, g, b;
   hex_to_rgb (hex, &r, &g, &b);

   rgb[0] = (r / 255.0);
   rgb[1] = (g / 255.0);
   rgb[2] = (b / 255.0);
}


void get_action (char *event, int *action)
{
   if (strcmp (event, "none") == 0)
      *action = NONE;
   else if (strcmp (event, "close") == 0)
      *action = CLOSE;
   else if (strcmp (event, "toggle") == 0)
      *action = TOGGLE;
   else if (strcmp (event, "iconify") == 0)
      *action = ICONIFY;
   else if (strcmp (event, "shade") == 0)
      *action = SHADE;
   else if (strcmp (event, "toggle_iconify") == 0)
      *action = TOGGLE_ICONIFY;
}


void add_entry (char *key, char *value)
{
   /* Font */
   if (strcmp (key, "font") == 0) 
      panel.font_desc = pango_font_description_from_string (value);
   else if (strcmp (key, "font_color") == 0)
      get_color (value, panel.font.color);
   else if (strcmp (key, "font_alpha") == 0)
      panel.font.alpha = (atoi (value) / 100.0);
   else if (strcmp (key, "font_active_color") == 0)
      get_color (value, panel.font_active.color);
   else if (strcmp (key, "font_active_alpha") == 0)
      panel.font_active.alpha = (atoi (value) / 100.0);
   else if (strcmp (key, "font_shadow") == 0)
      panel.font_shadow = atoi (value);

   /* Panel */
   else if (strcmp (key, "panel_show_all_desktop") == 0)
      panel.show_all_desktop = atoi (value);
   else if (strcmp (key, "panel_width") == 0)
      panel.width = atoi (value);
   else if (strcmp (key, "panel_height") == 0)
      panel.height = atoi (value);
   else if (strcmp (key, "panel_margin") == 0)
      panel.margin = atoi (value);
   else if (strcmp (key, "panel_position") == 0) {
      if (strcmp(value, "left") == 0) panel.position = LEFT;
      else if (strcmp(value, "right") == 0) panel.position = RIGHT;
      else panel.position = CENTER;
   }

   /* Panel Background */
   else if (strcmp (key, "panel_background") == 0)
      panel.drawBackground = atoi (value);
   else if (strcmp (key, "panel_background_color") == 0)
      get_color (value, panel.background.color);
   else if (strcmp (key, "panel_background_alpha") == 0)
      panel.background.alpha = (atoi (value) / 100.0);
   else if (strcmp (key, "panel_border_width") == 0)
      panel.border.width = atoi (value);
   else if (strcmp (key, "panel_border_color") == 0)
      get_color (value, panel.border.color);
   else if (strcmp (key, "panel_border_alpha") == 0)
      panel.border.alpha = (atoi (value) / 100.0);
   else if (strcmp (key, "panel_rounded") == 0)
      panel.border.rounded = atoi (value);

   /* Task */
   else if (strcmp (key, "task_text_centered") == 0)
      panel.task_text_centered = atoi (value);
   else if (strcmp (key, "task_width") == 0)
      panel.task_maximum_width = atoi (value);
   else if (strcmp (key, "task_margin") == 0)
      panel.task_margin = atoi (value);
   else if (strcmp (key, "task_padding") == 0)
      panel.task_padding = atoi (value);
   else if (strcmp (key, "task_icon") == 0)
      panel.task_icon = atoi (value);
   else if (strcmp (key, "task_icon_size") == 0)
      panel.task_icon_size = atoi (value);

   /* Task Background and border */
   else if (strcmp (key, "task_background") == 0)
      panel.task_background = atoi (value);
   else if (strcmp (key, "task_background_color") == 0)
      get_color (value, panel.task_back.color);
   else if (strcmp (key, "task_background_alpha") == 0)
      panel.task_back.alpha = (atoi (value) / 100.0);
   else if (strcmp (key, "task_active_background_color") == 0)
      get_color (value, panel.task_active_back.color);
   else if (strcmp (key, "task_active_background_alpha") == 0)
      panel.task_active_back.alpha = (atoi (value) / 100.0);

   else if (strcmp (key, "task_border_width") == 0)
      panel.task_border.width = atoi (value);
   else if (strcmp (key, "task_border_color") == 0)
      get_color (value, panel.task_border.color);
   else if (strcmp (key, "task_border_alpha") == 0)
      panel.task_border.alpha = (atoi (value) / 100.0);
   else if (strcmp (key, "task_rounded") == 0)
      panel.task_border.rounded = atoi (value);
   else if (strcmp (key, "task_active_border_width") == 0)
      panel.task_active_border.width = atoi (value);
   else if (strcmp (key, "task_active_border_color") == 0)
      get_color (value, panel.task_active_border.color);
   else if (strcmp (key, "task_active_border_alpha") == 0)
      panel.task_active_border.alpha = (atoi (value) / 100.0);
   else if (strcmp (key, "task_active_rounded") == 0)
      panel.task_active_border.rounded = atoi (value);

   /* Mouse actions */
   else if (strcmp (key, "mouse_middle") == 0)
      get_action (value, &panel.mouse_middle);
   else if (strcmp (key, "mouse_right") == 0)
      get_action (value, &panel.mouse_right);
   else if (strcmp (key, "mouse_scroll_up") == 0)
      get_action (value, &panel.mouse_scroll_up);
   else if (strcmp (key, "mouse_scroll_down") == 0)
      get_action (value, &panel.mouse_scroll_down);

   /* Launcher */
   else if (strcmp (key, "launcher_exec") == 0)
      launcher_add_exec (value);
   else if (strcmp (key, "launcher_icon") == 0)
      launcher_add_icon (value);
   else if (strcmp (key, "launcher_text") == 0)
      launcher_add_text (value);

   else
      fprintf(stderr, "Invalid option: \"%s\", correct your config file\n", key);

}


int parse_line (const char *line)
{
   char *a, *b, *key, *value;

   /* Skip useless lines */
   if ((line[0] == '#') || (line[0] == '\n')) return 0;
   if (!(a = strchr (line, '='))) return 0;

   /* overwrite '=' with '\0' */
   a[0] = '\0';
   key = strdup (line);
   a++;

   /* overwrite '\n' with '\0' if '\n' present */
   if ((b = strchr (a, '\n'))) b[0] = '\0';

   value = strdup (a);

   g_strstrip(key);
   g_strstrip(value);

   add_entry (key, value);

   free (key);
   free (value);
   return 1;
}


void alloc_taskbar(int copyOldTaskbar)
{
   Taskbar *newTaskbar;
   int i, nbDesktop, posx;

   nbDesktop = server_get_number_of_desktop ();
   if (nbDesktop == 0) {
      fprintf(stderr, "tint error : cannot found your desktop.\n");
      exit(0);
   }

   // alloc and copy old taskbar (if possible)
   newTaskbar = calloc(1, nbDesktop * sizeof(Taskbar));
   if (copyOldTaskbar) {
      for (i=0 ; i < nbDesktop ; i++) {
         if (i < panel.nbDesktop) {
            memcpy(&newTaskbar[i], &panel.taskbar[i], sizeof(Taskbar));
         }
      }
      free(panel.taskbar);
   }
   panel.nbDesktop = nbDesktop;
   panel.taskbar = newTaskbar;

   // initialise taskbar width and posx on all desktop
   int taskbar_width = panel.width - panel.launcher_width - (2 * panel.margin);
   if (panel.show_all_desktop) {
      // panel.task_height/3 between taskbars
      taskbar_width = (taskbar_width - ((nbDesktop-1) * (panel.task_height/3))) / nbDesktop;
   }
   posx = panel.margin;

   for (i=0 ; i < panel.nbDesktop ; i++) {
      panel.taskbar[i].text_width = panel.task_maximum_width - panel.task_text_posx - panel.task_padding;
      panel.taskbar[i].width = taskbar_width;
      panel.taskbar[i].posx = posx;
      if (panel.show_all_desktop) posx += taskbar_width + (panel.task_height/3);
      refresh_pos(i);
   }
}


void config_finish ()
{   
   if (!panel.width) panel.width = server.screen_width;
   panel.task_height = panel.height - (2 * panel.margin);
   panel.launcher_width = ((panel.margin + panel.task_height) * launcher.launcher_count);

   // add 1/6 of task_icon_size
   panel.task_text_posx = panel.task_padding;
   if (panel.task_icon) panel.task_text_posx += panel.task_icon_size + (panel.task_icon_size/6.0);
      
   alloc_taskbar(0);

   /* compute task vertical position for text and icon */
   //PangoRectangle logical_rect;
   cairo_surface_t *cs;
   cairo_t *c;
   int width, height;

   panel.task_icon_posy = (panel.task_height - panel.task_icon_size) / 2;

   Pixmap pmap = server_create_pixmap (panel.task_maximum_width, panel.task_height);
   cs = cairo_xlib_surface_create (server.dsp, pmap, server.visual, panel.task_maximum_width, panel.task_height);
   c = cairo_create (cs);
   
   PangoLayout *layout = pango_cairo_create_layout (c);
   pango_layout_set_font_description (layout, panel.font_desc);
   pango_layout_set_text (layout, "A", -1);
   //pango_layout_get_pixel_extents (layout, NULL, &logical_rect);
   pango_layout_get_pixel_size (layout, &width, &height);
   
   panel.task_text_posy = (panel.height - (2 * panel.margin) - height) / 2.0;
   g_object_unref (layout);
   
   cairo_destroy (c);
   cairo_surface_destroy (cs);
   XFreePixmap (server.dsp, pmap);
}


void config_free ()
{
   if (panel.font_desc) pango_font_description_free(panel.font_desc);
   if (panel.taskbar) free(panel.taskbar);
}


void config_read ()
{
   char line[80], *path;
   FILE *fp;

   /* read tint config */
   path = g_build_filename (g_get_home_dir(), ".config", "tint", "tintrc", NULL);
   fp = fopen(path, "r");

   // a voir : cela n'amene rien par rapport a avant
   memset(&panel, 0, sizeof(Panel));
   launcher.launcherlist = NULL;
   launcher.launcher_count = 0;

   if (!fp) {
      fprintf(stderr, "tint error : cannot open config file.\nCopy tintrc_sample to ~/.config/tint/tintrc directory\n");
      panel.font_desc = pango_font_description_from_string ("sans bold 8");
      panel.font.alpha = panel.font_active.alpha = 1;
      panel.height = 30;
      panel.task_maximum_width = 80;
   }
   else {
      while (fgets(line, 80, fp) != NULL) parse_line (line);

      fclose (fp);
   }
   g_free(path);
}


