
#ifndef VISUAL_H
#define VISUAL_H

void refresh_visual ();
void visual_draw_tasks ();
void visual_draw_launcher ();
void draw_panel_background ();

#endif
