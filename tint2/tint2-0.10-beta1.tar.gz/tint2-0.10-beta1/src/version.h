
#define VERSION_STRING "0.10-beta1"

