MKV Chapter Creator
-------------------
Creates the chapter creation instructions used by mkvmerge. One chapter is created per file.

The program's interface is split into three areas:

1. The top section is the list of files to be merged. The files should be in the same order that mkvmerge will use to join the files. The list is populated by dragging and dropping the files on to the program (any location apart from the list itself). Once the list is populated the files can be rearranged by the usual use of dragging and dropping within the list. (Hold ctrl down to select multiple files. Press Del to remove the selected files from the list. Ctrl+a selects all the files.)

2. The middle section describes the format of the chapter description instructions that will be used by mkvmerge. The default contents of this section should work in most cases so shouldn't need to be changed. However, the aim was to provide the user with flexibility its format to the extent that it might be possible to use the program for other applications, not just with mkvmerge.

3. Once the top and middle sections are ready, click Process to have the bottom section populated. It is now possible to tweak the generated text if necessary. Otherwise copy and paste the text into a text file that will be used by mkvmerge.

Within mkvmerge, use the menu item Chapter Editor -> Load to load the text file created above.

Changes
-------
4 June 2012    First version




Acknowledgments
---------------
From an idea published here: http://forum.videohelp.com/threads/300761-Create-chapter-file-for-MKV-video?p=2166377#post2166377
Uses SSDiver2112's gListView control available here:
http://www.codeproject.com/Articles/34676/gListView-ListView-Control-with-Visual-Drag-and-Dr