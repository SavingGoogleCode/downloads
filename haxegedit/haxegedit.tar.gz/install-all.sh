#!/bin/sh

cd ./gedit-haxe-codecompletion
sh ./install.sh

cd ../gedit-haxe-ide
sh ./install.sh

cd ../gedit-haxe-syntaxhighlighting
sh ./install.sh

cd ../gedit-codebrowser
sh ./install.sh

cd ../ctags
sh ./install.sh
