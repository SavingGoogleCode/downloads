#! /usr/bin/env bash

echo 'neko application.n 13 17'

gnome-terminal --command="neko ./bin/application.n 13 17"
