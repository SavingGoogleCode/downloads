#! /usr/bin/env bash

php ./bin/index.php 13 17
