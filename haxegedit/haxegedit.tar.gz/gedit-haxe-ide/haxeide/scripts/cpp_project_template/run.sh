#! /usr/bin/env bash

bin/Main 13 17
