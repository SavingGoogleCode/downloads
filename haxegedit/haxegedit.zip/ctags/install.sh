echo "*** Installing ctags for haxe ***"
echo "cp ./ctags-5.8/ctags /usr/local/bin/ctags"
cp ./ctags-5.8/ctags /usr/local/bin/ctags  &&  chmod 755 /usr/local/bin/ctags
echo "Done installing ctags for haXe.\n"
