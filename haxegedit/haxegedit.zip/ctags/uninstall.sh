echo "*** Uninstalling ctags for haxe ***"
rm -f /usr/local/bin/ctags
echo "Done uninstalling ctags for haXe.\n"
