"""Load the python code completion plugin"""
import haxeide
from haxeide import haxeide
