#! /usr/bin/env bash

flashplayer ./bin/index.swf
#firefox ./bin/index.html
