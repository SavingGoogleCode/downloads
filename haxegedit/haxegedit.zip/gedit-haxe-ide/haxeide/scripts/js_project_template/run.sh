#! /usr/bin/env bash

firefox ./bin/index.html
